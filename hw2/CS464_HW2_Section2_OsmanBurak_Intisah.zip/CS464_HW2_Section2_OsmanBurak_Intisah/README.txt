I have done my homework in python language. 

To be able to read the given datas you need to change the root variable in the code, 
to the path of the directory where all 2 data files include.


Terminal Command:

After changing the root variable, if python 3 is loaded in your system you can go to your terminal 
and going under the directory of the files,
and type, 
	
		python h2main.py

Then corresponding plots and outputs will appear. 

If you dont have python 3 you can download anaconda 3. And do the steps that are explained above 
in anaconda prompt window.


Default Values:


How to read outputs:

The outputs provided with the labels in front of them. They are indicating the corresponding questions. 



NOTE 1:
While doing this homework I have used google colab. If you want to check it from the I am providing the link 
for my homework.

https://colab.research.google.com/drive/1kJ_Q8o5RNEBF61vbBmKe32NA7rrmdd8c?usp=sharing

Or (if this link does not work) there is also a link at the beginning of the h2main.py. You can also enter that link to the browser and check the corresponding outputs.

NOTE 2:
I have also provided the notebook version of my code which is (h2main.ipynb). You can open this in your colab notebook. 
But if you want to see the outputs you need to change the root to the folder in your drive which includes the input files. 


Osman Burak INTISAH
21602430
Section 2
